export default `<!doctype html>
<html lang="en" data-beasties-container="">
<head>
  <meta charset="utf-8">
  <title>MIS - Technical</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="stylesheet" href="styles-5INURTSO.css"></head>
<body ngcm="">
  <app-root></app-root>
<link rel="modulepreload" href="chunk-GJIBC6UF.js"><link rel="modulepreload" href="chunk-LIEZ2ITH.js"><link rel="modulepreload" href="chunk-MUDCCABQ.js"><link rel="modulepreload" href="chunk-CZYRBYFX.js"><link rel="modulepreload" href="chunk-JIHJJZXD.js"><link rel="modulepreload" href="chunk-A55UN5VK.js"><link rel="modulepreload" href="chunk-E324PCFT.js"><link rel="modulepreload" href="chunk-KBYFNXXX.js"><script src="main-K5KWY2YL.js" type="module"></script></body>
</html>
`;