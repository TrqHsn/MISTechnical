export default `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>MIS - Technical</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="stylesheet" href="styles-5INURTSO.css"></head>
<body><script type="text/javascript" id="ng-event-dispatch-contract">(()=>{function p(t,n,r,o,e,i,f,m){return{eventType:t,event:n,targetElement:r,eic:o,timeStamp:e,eia:i,eirp:f,eiack:m}}function u(t){let n=[],r=e=>{n.push(e)};return{c:t,q:n,et:[],etc:[],d:r,h:e=>{r(p(e.type,e,e.target,t,Date.now()))}}}function s(t,n,r){for(let o=0;o<n.length;o++){let e=n[o];(r?t.etc:t.et).push(e),t.c.addEventListener(e,t.h,r)}}function c(t,n,r,o,e=window){let i=u(t);e._ejsas||(e._ejsas={}),e._ejsas[n]=i,s(i,r),s(i,o,!0)}window.__jsaction_bootstrap=c;})();
</script>
  <app-root></app-root>
<link rel="modulepreload" href="chunk-GJIBC6UF.js"><link rel="modulepreload" href="chunk-LIEZ2ITH.js"><link rel="modulepreload" href="chunk-MUDCCABQ.js"><link rel="modulepreload" href="chunk-CZYRBYFX.js"><link rel="modulepreload" href="chunk-JIHJJZXD.js"><link rel="modulepreload" href="chunk-A55UN5VK.js"><link rel="modulepreload" href="chunk-E324PCFT.js"><link rel="modulepreload" href="chunk-KBYFNXXX.js"><script src="main-K5KWY2YL.js" type="module"></script></body>
</html>
`;